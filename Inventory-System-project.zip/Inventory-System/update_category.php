<?php

include 'includes/db.php';

if((isset($_POST['category'])) && (isset($_POST['category_qty'])) &&   (isset($_POST['category_desc'])))
{


  $catname = $_POST['category'];
  $catqty = $_POST['category_qty'];
  $catdesc = $_POST['category_desc'];

  $category_id = $_POST['category_id'];
   
  
  $sqladd = "UPDATE categories set name = ? , qty = ? , description = ?  where id = ?";
  $sqladdresults = $conn->prepare($sqladd);
  $sqladdresults->bind_param('sisi',$catname,$catqty,$catdesc,$category_id);

  if($sqladdresults->execute())
  {
    header('Location:categories.php');
  }
  else
  {
    header('Location:index.php');
    exit();
  }

}
else
{
  header('Location:index.php');
    exit();
}







?>