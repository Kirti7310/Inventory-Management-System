<?php

include 'includes/db.php';

if((isset($_POST['category'])) && (isset($_POST['category_qty'])) &&   (isset($_POST['category_desc'])))
{

  $catname = $_POST['category'];
  $catqty = $_POST['category_qty'];
  $catdesc = $_POST['category_desc'];



  $sqladd = "INSERT INTO  categories(name,qty,description) VALUES (?, ?, ?)";
  $sqladdresults = $conn->prepare($sqladd);
  $sqladdresults->bind_param('sis',$catname,$catqty,$catdesc);

  if($sqladdresults->execute())
  {
    header('Location:categories.php');
  }
  else
  {
    header('Location:index.php');
    exit();
  }

}
else
{
  header('Location:index.php');
    exit();
}







?>