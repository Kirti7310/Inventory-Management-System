<?php

include 'includes/db.php';

if((isset($_POST['category_id'])))
{

  $catname = $_POST['category'];
  $catqty = $_POST['category_qty'];
  $catdesc = $_POST['category_desc'];

  $category_id = $_POST['category_id'];
   
  
  $sqladd = "delete from categories where id = ?";
  $sqladdresults = $conn->prepare($sqladd);
  $sqladdresults->bind_param('i',$category_id);

  if($sqladdresults->execute())
  {
    header('Location:categories.php');
  }
  else
  {
    header('Location:index.php');
    exit();
  }

}
else
{
  header('Location:index.php');
    exit();
}







?>