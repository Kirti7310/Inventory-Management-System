
<?php

session_start();
include 'includes/db.php';



$role ="";
$categories=[];



if(isset($_SESSION['email']))
  
{
  $email = $_SESSION['email'];

  $sql = 'select role from users where username =? ';
  $sqlresults = $conn->prepare($sql);
  $sqlresults->bind_param('s',$email) ;
  $sqlresults->execute();
  $sqlcategories = $sqlresults->get_result();

  if($sqlcategories->num_rows>0)
  {
    while($row=$sqlcategories->fetch_assoc())
    {
      if($row['role'] === 'user')
      {

        $sql = "select id,name,qty,description from categories";
        $sqlresultscat = $conn->query($sql);

        if($sqlresultscat->num_rows>0)
        {
          while($row=$sqlresultscat->fetch_assoc())
          {
            $categories[] = $row;
          }
        }
        $role = "user";

      }
      else
      {
        

        $sqladmin = "select id,name,qty,description from categories";
        $sqlresultscatadmin = $conn->query($sqladmin);

        if($sqlresultscatadmin->num_rows>0)
        {
          while($row=$sqlresultscatadmin->fetch_assoc())
          {
            $categories[] = $row;
          }
        }

        $role = "admin";
      }
    }
  }


}


?>  
    
    
    <?php 
    header('Content-Type:text/csv');
    header('Content-Disposition: attachment; filename="categories.csv"');


    $output = fopen('php://output','w');
    fputcsv($output, ['Name', 'Quantity', 'Description']);

    foreach ($categories as $category) {
      fputcsv($output, $category);
  }

  fclose($output);
exit;

    
?>