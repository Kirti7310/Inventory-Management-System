<?php

$username = 'root'; 
$password = '';     
$db_name = 'inventory_management'; 
$hostname = 'localhost'; 

$conn = new mysqli($hostname, $username, $password, $db_name);

if ($conn->connect_error) {
    die("Connection unsuccessful: " . $conn->connect_error);
}
?>