<?php

session_start();
include 'includes/db.php';



$role ="";
$categories=[];



if(isset($_SESSION['email']))
  
{
  $email = $_SESSION['email'];

  $sql = 'select role from users where username =? ';
  $sqlresults = $conn->prepare($sql);
  $sqlresults->bind_param('s',$email) ;
  $sqlresults->execute();
  $sqlcategories = $sqlresults->get_result();

  if($sqlcategories->num_rows>0)
  {
    while($row=$sqlcategories->fetch_assoc())
    {
      if($row['role'] === 'user')
      {

        $sql = "select id,name,qty,description from categories";
        $sqlresultscat = $conn->query($sql);

        if($sqlresultscat->num_rows>0)
        {
          while($row=$sqlresultscat->fetch_assoc())
          {
            $categories[] = $row;
          }
        }
        $role = "user";

      }
      else
      {
        

        $sqladmin = "select id,name,qty,description from categories";
        $sqlresultscatadmin = $conn->query($sqladmin);

        if($sqlresultscatadmin->num_rows>0)
        {
          while($row=$sqlresultscatadmin->fetch_assoc())
          {
            $categories[] = $row;
          }
        }

        $role = "admin";
      }
    }
  }


}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="assets/style.css">
    <!-- Link to CSS -->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <!-- Link to jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
<?php if($role === "user"):?>

  <div class="container">
    <div class="cont-cat">
      <h1> Category List </h1>
    <?php foreach($categories as $categories_each):?>
      <h3><?php echo htmlspecialchars($categories_each['name']) ?></h3>
      <p><?php echo htmlspecialchars($categories_each['qty']) ?></p>
      <p><?php echo htmlspecialchars($categories_each['description']) ?> </p>
    <?php endforeach; ?>
    </div>
  </div>

  <div>
  <a href="download.php" class="explore-btn" style="display: flex; flex-direction:column; justify-content:center; text-align: center; padding: 10px 20px; background-color:rgb(131, 132, 134); color: white; text-decoration: none; border-radius: 5px;">
    Download CSV
  </a>
</div>

  



<?php endif; ?>

<?php if($role === "admin"): ?>

<div class="form-container">
  <div class="container-entry">

    <div class="container">
      <div class="cont-cat">
        <?php if(!empty($categories)): ?>
          <?php foreach($categories as $categories_each): ?>
            <h3><?php echo htmlspecialchars($categories_each['name']); ?></h3>
            <p><?php echo htmlspecialchars($categories_each['qty']); ?></p>
            <p><?php echo htmlspecialchars($categories_each['description']); ?></p>
            <form action="update_category.php" method="POST" class="form-categories">
            <input type="hidden" name="category_id" value="<?php echo $categories_each['id']; ?>">
              <input class="input-main-cat" type="text" name="category" value="<?php echo htmlspecialchars($categories_each['name']); ?>" placeholder="Update Category Name">
              <input class="input-main-cat" type="number" name="category_qty" value="<?php echo htmlspecialchars($categories_each['qty']); ?>" placeholder="Update Category Qty">
              <textarea class="input-main-cat" name="category_desc" placeholder="Update Category Description"><?php echo htmlspecialchars($categories_each['description']); ?></textarea>
              <button type="submit" name="update_category">UPDATE CATEGORY</button>
            </form>
            <form action="delete_category.php" method="POST" class="form-categories">
              <input type="hidden" name="category_id" value="<?php echo $categories_each['id']; ?>">
              <button type="submit" name="delete_category">DELETE CATEGORY</button>
            </form>


            
          <?php endforeach; ?>
          <h2>Add New Category</h2>
            <form action="add_categories.php" method="POST" class="form-categories">
            <label for="category_name">Category Name:</label>
            <input id="category" class="input-main-cat" type="text" name="category" placeholder="Enter Category Name" required>

            <label for="qty">Category Qty:</label>
            <input id="category_qty" class="input-main-cat" type="number" name="category_qty" placeholder="Enter Category Qty" required>

            <label for="qty">Category Description:</label>
            <textarea id="category_desc" class="input-main-cat" name="category_desc" placeholder="Enter Category Description" required></textarea>

            <button type="submit" name="add_category">ADD CATEGORY</button>
          </form>
        <?php else: ?>

          <form action="add_categories.php" method="POST" class="form-categories">
            <label for="category_name">Category Name:</label>
            <input id="category" class="input-main-cat" type="text" name="category" placeholder="Enter Category Name" required>

            <label for="qty">Category Qty:</label>
            <input id="category_qty" class="input-main-cat" type="number" name="category_qty" placeholder="Enter Category Qty" required>

            <label for="qty">Category Description:</label>
            <textarea id="category_desc" class="input-main-cat" name="category_desc" placeholder="Enter Category Description" required></textarea>

            <button type="submit" name="add_category">ADD CATEGORY</button>
          </form>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<?php endif; ?>

<section class="content-main">
  <div id="home-page" class="homepage" style="text-align: center;">
    <a href="index.php" style="text-decoration:none; color:#fff; padding:10px;">
      <h3 class="home-page-class"><i class="fa-solid fa-house"></i> Homepage</h3>
    </a>
  </div>
</section>



<footer style="background-color: #333; color: #fff; padding: 20px; text-align: center; font-size: 14px;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <p>&copy; <?php echo date('Y'); ?> Inventory Management System. All Rights Reserved.</p>

        <div style="margin: 10px 0;">
            <a href="/about-us" style="color: #ddd; text-decoration: none; margin: 0 10px;">About Us</a> |
            <a href="/contact" style="color: #ddd; text-decoration: none; margin: 0 10px;">Contact</a> |
            <a href="/privacy-policy" style="color: #ddd; text-decoration: none; margin: 0 10px;">Privacy Policy</a>
        </div>

      

        <p style="margin-top: 10px;">For technical support, email us at <a href="mailto:support@inventorysystem.com" style="color: #4CAF50; text-decoration: none;">support@inventorysystem.com</a></p>
    </div>
</footer>









  
</body>
</html>