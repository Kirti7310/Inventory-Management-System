<?php
session_start();

include 'includes/db.php';

if (
    isset($_POST['email']) &&
    isset($_POST['password']) 
) {
    

      $sqllogin = 'SELECT * FROM users where username = ? ';
      $sqlresults  = $conn->prepare($sqllogin);
      $sqlresults->bind_param('s',$_POST['email']);
      $sqlresults->execute();
      $loginresults=$sqlresults->get_result();

      if($loginresults->num_rows > 0 )
      {
        while($row = $loginresults->fetch_assoc())
        {
            if(password_verify($_POST['password'],$row['password']))
            {


            


              $_SESSION['name'] = $row['name'];
              $_SESSION['email'] = $row['username'];

              header('Location:index.php');
              exit();
            }
            else
            {
              $_SESSION['error'] = "Password Dosen't Match!";
              header('Location:login.php');
              exit();
            }
      }


    }

       else {


        $_SESSION['error'] = "User Not Found!";
        header('Location:login.php');
        exit();
       
    }
}
else
{

  $_SESSION['error'] = "Please fill in all the required fields!";
    header('Location: login.php');
    exit();
}
?>
